import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

interface App {
  name: string;
  icon: string;
  command: string;
}

@Injectable({
  providedIn: 'root'
})
export class AppService {
  private apiUrl = 'http://localhost:2354';

  constructor(private http: HttpClient) { }

  getApps(): Observable<App[]> {
    return this.http.get<App[]>(`${this.apiUrl}/apps`);
  }

  launchApp(name: string): Observable<string> {
    return this.http.post<string>(`${this.apiUrl}/launch`, { name });
  }
}
