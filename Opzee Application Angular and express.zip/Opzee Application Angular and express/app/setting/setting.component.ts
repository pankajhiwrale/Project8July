import { Component } from '@angular/core';

@Component({
  selector: 'app-setting',
  templateUrl: './setting.component.html',
  styleUrls: ['./setting.component.css']
})
export class SettingComponent {
  comment: string = '';

  submitComment(): void {
    console.log('Comment submitted:', this.comment);
    // Add logic to handle the comment submission (e.g., send to server)
    alert('Comment submitted: ' + this.comment);
    this.comment = '';  // Clear the comment box after submission
  }
}

