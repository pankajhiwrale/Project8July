import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoadingComponent } from './loading/loading.component';
import { LauncherComponent } from './components/launcher/launcher.component';
import { SettingComponent } from './setting/setting.component';

const routes: Routes = [
  { path: '', redirectTo: '/launcher', pathMatch: 'full' },
  { path: 'launcher', component: LauncherComponent },
  { path: 'loading', component: LoadingComponent },
  { path: 'settings', component: SettingComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
