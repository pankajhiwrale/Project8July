import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from 'src/app/services/application.service';

interface App {
  name: string;
  icon: string;
  command: string;
}

@Component({
  selector: 'app-launcher',
  templateUrl: './launcher.component.html',
  styleUrls: ['./launcher.component.css']
})
export class LauncherComponent implements OnInit {
  apps: App[] = [];

  constructor(private appService: AppService, private router: Router) { }

  ngOnInit(): void {
    this.appService.getApps().subscribe(apps => {
      this.apps = apps;
    });
  }
  
  launchApp(name: string): void {
    this.router.navigate(['/loading'], { queryParams: { name: name } });
    this.appService.launchApp(name).subscribe(response => {
      console.log(response);
    }, error => {
      console.error('Error launching app:', error);
    });
  }
}