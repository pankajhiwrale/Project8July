const express = require('express');
const path = require('path');
const app = express();
const port = 2354;
const bodyParser = require('body-parser');
const cors = require('cors');

const apps = [
    { name: 'baseball', icon: '/assets/baseball.png', command: 'path/to/baseball.exe' },
    { name: 'cricket', icon: 'assets/cricket.png', command: 'path/to/cricket.exe' },
    { name: 'architecture', icon: 'assets/architecture.png', command: 'path/to/architecture.exe' },
    { name: 'paris', icon: 'assets/paris.png', command: 'path/to/paris.exe' },
    { name: 'baseball', icon: '/assets/baseball.png', command: 'path/to/baseball.exe' },
    { name: 'cricket', icon: 'assets/cricket.png', command: 'path/to/cricket.exe' },
    { name: 'architecture', icon: 'assets/architecture.png', command: 'path/to/architecture.exe' },
    { name: 'paris', icon: 'assets/paris.png', command: 'path/to/paris.exe' },
    { name: 'cricket', icon: 'assets/cricket.png', command: 'path/to/cricket.exe' },
    { name: 'paris', icon: 'assets/paris.png', command: 'path/to/paris.exe' }

];

app.use(cors());
app.use(bodyParser.json());
app.use('/assets', express.static(path.join(__dirname, 'assets')));

app.get('/apps', (req, res) => {
    res.json(apps);
});

app.post('/launch', (req, res) => {
    const appName = req.body.name;
    const app = apps.find(a => a.name === appName);

    if (app) {
        console.log(`Launching ${app.name} with command ${app.command}`);
        res.status(200).send(`Launching ${app.name}`);
    } else {
        res.status(404).send('App not found');
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/`);
});